
Water Meter - v2 saved_meters_no_aug
==============================

This dataset was exported via roboflow.ai on November 28, 2021 at 4:57 PM GMT

It includes 610 images.
Numbers are annotated in COCO format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


